package dev.pluscraft.client;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.pluscraft.config.PlusCraftConfig;
import dev.pluscraft.social.FriendsList;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.text.Text;
import net.minecraft.world.GameMode;

/** Client entrypoint: /pc host, /pc friends. */
public class PlusCraftClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("pc")
                        .then(ClientCommandManager.literal("host")
                                .executes(ctx -> host(ctx.getSource(), PlusCraftConfig.get().defaultPort))
                                .then(ClientCommandManager.argument("port", IntegerArgumentType.integer(1024, 65535))
                                        .executes(ctx -> host(ctx.getSource(),
                                                IntegerArgumentType.getInteger(ctx, "port")))))
                        .then(ClientCommandManager.literal("friends")
                                .then(ClientCommandManager.literal("list").executes(ctx -> {
                                    say(ctx.getSource(), FriendsList.all().isEmpty()
                                            ? "No friends yet. Use /pc friends add <name>"
                                            : "Friends: " + String.join(", ", FriendsList.all()));
                                    return 1;
                                }))
                                .then(ClientCommandManager.literal("add")
                                        .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                                .executes(ctx -> {
                                                    String n = StringArgumentType.getString(ctx, "name");
                                                    say(ctx.getSource(), FriendsList.add(n)
                                                            ? "Added " + n : n + " is already a friend");
                                                    return 1;
                                                })))
                                .then(ClientCommandManager.literal("remove")
                                        .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                                .executes(ctx -> {
                                                    String n = StringArgumentType.getString(ctx, "name");
                                                    say(ctx.getSource(), FriendsList.remove(n)
                                                            ? "Removed " + n : n + " is not in your list");
                                                    return 1;
                                                })))))
                        .then(ClientCommandManager.literal("offline-mode")
                                .then(ClientCommandManager.argument("on", StringArgumentType.word())
                                        .executes(ctx -> {
                                            boolean on = StringArgumentType.getString(ctx, "on").equalsIgnoreCase("on");
                                            PlusCraftConfig.get().allowOfflineAccounts = on;
                                            PlusCraftConfig.get().save();
                                            say(ctx.getSource(), "Offline accounts allowed when hosting: " + on);
                                            return 1;
                                        })))));
    }

    private static int host(FabricClientCommandSource source, int port) {
        MinecraftClient mc = MinecraftClient.getInstance();
        IntegratedServer server = mc.getServer();
        if (server == null) {
            say(source, "Open a single-player world first.");
            return 0;
        }
        if (PlusCraftConfig.get().allowOfflineAccounts) {
            server.setOnlineMode(false);
        }
        boolean ok = server.openToLan(GameMode.SURVIVAL, false, port);
        say(source, ok ? "World is open on port " + port + ". Friends join via your IP:" + port
                : "Could not open the world (port in use or already open).");
        return ok ? 1 : 0;
    }

    private static void say(FabricClientCommandSource source, String msg) {
        source.sendFeedback(Text.literal("[PlusCraft] " + msg));
    }
}
