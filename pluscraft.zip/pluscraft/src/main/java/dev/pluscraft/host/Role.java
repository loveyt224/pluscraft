package dev.pluscraft.host;

import net.minecraft.world.GameMode;

/** Per-player permission tiers for hosted worlds. */
public enum Role {
    SPECTATOR(GameMode.SPECTATOR),
    VISITOR(GameMode.ADVENTURE),
    BUILDER(GameMode.SURVIVAL),
    OPERATOR(GameMode.SURVIVAL);

    public final GameMode gameMode;

    Role(GameMode gameMode) {
        this.gameMode = gameMode;
    }

    public static Role parse(String s, Role fallback) {
        try {
            return Role.valueOf(s.toUpperCase());
        } catch (Exception e) {
            return fallback;
        }
    }
}
