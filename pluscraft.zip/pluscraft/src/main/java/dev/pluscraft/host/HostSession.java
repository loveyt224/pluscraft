package dev.pluscraft.host;

import dev.pluscraft.config.PlusCraftConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Locale;

/**
 * Host-side moderation for a shared single-player world.
 * Only touches live session state; world files are left alone.
 */
public final class HostSession {
    private static String hostName; // first player to join a non-dedicated server

    private HostSession() {
    }

    public static void onJoin(MinecraftServer server, ServerPlayerEntity player) {
        PlusCraftConfig cfg = PlusCraftConfig.get();
        String name = player.getName().getString();
        String key = name.toLowerCase(Locale.ROOT);

        if (!server.isDedicated() && hostName == null) {
            hostName = key;
            return; // host is never restricted
        }
        if (server.isDedicated() || key.equals(hostName)) {
            return;
        }

        if (cfg.blacklist.contains(key)) {
            player.networkHandler.disconnect(Text.literal("You are blacklisted from this world."));
            return;
        }
        if (cfg.whitelistEnabled && !cfg.whitelist.contains(key)) {
            player.networkHandler.disconnect(Text.literal("You are not whitelisted on this world."));
            return;
        }
        if (server.getPlayerManager().getCurrentPlayerCount() > cfg.maxPeers + 1) {
            player.networkHandler.disconnect(Text.literal("The lobby is full."));
            return;
        }
        applyRole(server, player, roleOf(key));
    }

    public static void onStop() {
        hostName = null;
    }

    public static boolean isHost(ServerPlayerEntity player) {
        return hostName != null && player.getName().getString().toLowerCase(Locale.ROOT).equals(hostName);
    }

    public static Role roleOf(String lowerName) {
        PlusCraftConfig cfg = PlusCraftConfig.get();
        return Role.parse(cfg.roles.getOrDefault(lowerName, cfg.defaultRole), Role.BUILDER);
    }

    public static void applyRole(MinecraftServer server, ServerPlayerEntity player, Role role) {
        player.changeGameMode(role.gameMode);
        if (role == Role.OPERATOR) {
            server.getCommandManager().executeWithPrefix(server.getCommandSource(),
                    "op " + player.getName().getString());
        }
    }
}
