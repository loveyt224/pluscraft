package dev.pluscraft.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Persistent settings, stored as config/pluscraft.json. */
public class PlusCraftConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static PlusCraftConfig instance;

    // ---- Host control suite ----
    public boolean whitelistEnabled = false;
    public List<String> whitelist = new ArrayList<>();
    public List<String> blacklist = new ArrayList<>();
    /** player name (lowercase) -> SPECTATOR | VISITOR | BUILDER | OPERATOR */
    public Map<String, String> roles = new HashMap<>();
    public String defaultRole = "BUILDER";
    public int maxPeers = 8;
    /**
     * Same effect as online-mode=false in server.properties for the hosted session.
     * Off by default. Offline players then join with offline UUIDs like on any
     * offline-mode server; no authentication is forged or spoofed.
     */
    public boolean allowOfflineAccounts = false;
    public int defaultPort = 25565;

    // ---- Social (local) ----
    public List<String> friends = new ArrayList<>();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("pluscraft.json");
    }

    public static synchronized PlusCraftConfig get() {
        if (instance == null) {
            try {
                if (Files.exists(path())) {
                    instance = GSON.fromJson(Files.readString(path()), PlusCraftConfig.class);
                }
            } catch (Exception ignored) {
            }
            if (instance == null) {
                instance = new PlusCraftConfig();
                instance.save();
            }
        }
        return instance;
    }

    public synchronized void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }
}
