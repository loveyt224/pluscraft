package dev.pluscraft;

import com.mojang.brigadier.arguments.StringArgumentType;
import dev.pluscraft.config.PlusCraftConfig;
import dev.pluscraft.host.HostSession;
import dev.pluscraft.host.Role;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;

/** Common/server entrypoint: host control suite for hosted worlds. */
public class PlusCraft implements ModInitializer {
    public static final String MOD_ID = "pluscraft";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        PlusCraftConfig.get();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                HostSession.onJoin(server, handler.player));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> HostSession.onStop());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("pchost")
                        .then(listCmd("whitelist"))
                        .then(listCmd("blacklist"))
                        .then(CommandManager.literal("whitelist-mode")
                                .then(CommandManager.argument("on", StringArgumentType.word())
                                        .executes(ctx -> hostOnly(ctx.getSource(), () -> {
                                            boolean on = StringArgumentType.getString(ctx, "on").equalsIgnoreCase("on");
                                            PlusCraftConfig.get().whitelistEnabled = on;
                                            PlusCraftConfig.get().save();
                                            reply(ctx.getSource(), "Whitelist " + (on ? "enabled" : "disabled"));
                                        }))))
                        .then(CommandManager.literal("role")
                                .then(CommandManager.argument("player", StringArgumentType.word())
                                        .then(CommandManager.argument("role", StringArgumentType.word())
                                                .executes(ctx -> hostOnly(ctx.getSource(), () -> {
                                                    String p = StringArgumentType.getString(ctx, "player");
                                                    Role r = Role.parse(StringArgumentType.getString(ctx, "role"), null);
                                                    if (r == null) {
                                                        reply(ctx.getSource(), "Roles: spectator, visitor, builder, operator");
                                                        return;
                                                    }
                                                    PlusCraftConfig.get().roles.put(p.toLowerCase(Locale.ROOT), r.name());
                                                    PlusCraftConfig.get().save();
                                                    ServerPlayerEntity target = ctx.getSource().getServer()
                                                            .getPlayerManager().getPlayer(p);
                                                    if (target != null) {
                                                        HostSession.applyRole(ctx.getSource().getServer(), target, r);
                                                    }
                                                    reply(ctx.getSource(), p + " is now " + r.name().toLowerCase());
                                                })))))));

        LOGGER.info("PlusCraft loaded.");
    }

    /** /pchost <whitelist|blacklist> <add|remove> <player> */
    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<ServerCommandSource> listCmd(String list) {
        return CommandManager.literal(list)
                .then(CommandManager.literal("add")
                        .then(CommandManager.argument("player", StringArgumentType.word())
                                .executes(ctx -> hostOnly(ctx.getSource(), () -> {
                                    String p = StringArgumentType.getString(ctx, "player").toLowerCase(Locale.ROOT);
                                    PlusCraftConfig cfg = PlusCraftConfig.get();
                                    var l = list.equals("whitelist") ? cfg.whitelist : cfg.blacklist;
                                    if (!l.contains(p)) l.add(p);
                                    cfg.save();
                                    reply(ctx.getSource(), "Added " + p + " to " + list);
                                }))))
                .then(CommandManager.literal("remove")
                        .then(CommandManager.argument("player", StringArgumentType.word())
                                .executes(ctx -> hostOnly(ctx.getSource(), () -> {
                                    String p = StringArgumentType.getString(ctx, "player").toLowerCase(Locale.ROOT);
                                    PlusCraftConfig cfg = PlusCraftConfig.get();
                                    (list.equals("whitelist") ? cfg.whitelist : cfg.blacklist).remove(p);
                                    cfg.save();
                                    reply(ctx.getSource(), "Removed " + p + " from " + list);
                                }))));
    }

    private static int hostOnly(ServerCommandSource source, Runnable action) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null || !HostSession.isHost(player)) {
            reply(source, "Only the world host can use this.");
            return 0;
        }
        action.run();
        return 1;
    }

    private static void reply(ServerCommandSource source, String msg) {
        source.sendFeedback(() -> Text.literal("[PlusCraft] " + msg), false);
    }
}
