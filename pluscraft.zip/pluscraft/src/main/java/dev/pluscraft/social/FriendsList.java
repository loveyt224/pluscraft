package dev.pluscraft.social;

import dev.pluscraft.config.PlusCraftConfig;

import java.util.List;
import java.util.Locale;

/** Local friends list. Presence and messaging need a transport layer (see README roadmap). */
public final class FriendsList {
    private FriendsList() {
    }

    public static List<String> all() {
        return PlusCraftConfig.get().friends;
    }

    public static boolean add(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (all().contains(n)) return false;
        all().add(n);
        PlusCraftConfig.get().save();
        return true;
    }

    public static boolean remove(String name) {
        boolean removed = all().remove(name.toLowerCase(Locale.ROOT));
        if (removed) PlusCraftConfig.get().save();
        return removed;
    }
}
